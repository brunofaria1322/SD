Hello! Thanks for using our app!

Here are some quick instructions:
on Windows -> click the .bat files to execute each component of the project.
on other OS -> write "java -jar name_of_the_file.jar" on a command line and press ENTER. Example: "java -jar RMIServer.jar"



Notes:
->The RMI Server only becomes operational when two instances of the RMIServer are executed.
->The config folder MUST stay in the same directory as the VotingTerminal.jar or the MulticastServer.jar for them to work.
->The address, port and voting station id in the config files may be changed.
->The lib folder must be in the same directory as the .jar files for them to work.